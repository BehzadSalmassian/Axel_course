# Step 1: Handle Command Line

if __name__ == "__main__":
    print("Simple script to plot x and y values.")

